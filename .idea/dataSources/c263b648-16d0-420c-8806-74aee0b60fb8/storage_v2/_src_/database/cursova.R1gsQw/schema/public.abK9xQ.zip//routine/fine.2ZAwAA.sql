create function fine() returns trigger
    language plpgsql
as
$$
declare finedays bigint;
        finecost bigint;
BEGIN

    SELECT (current_date - ticket.ticketdate) into finedays FROM ticket where ticketid=new.ticketid;
    SELECT penaltycost into finecost FROM penalty join ticket t on penalty.penaltyid = t.penaltyid where ticketid=new.ticketid;
    if (new.cost is null or new.cost = old.cost) and current_date - new.ticketdate > 30 then
        Update ticket
        set cost = (finedays - 29) * 0.1 * finecost + finecost
        where ticketid=new.ticketid;
    elsif current_date - new.ticketdate <= 30 and new.cost is null then
        Update ticket
        set cost = finecost
        where ticketid=new.ticketid;
    end if;
        return null;
end;
$$;

alter function fine() owner to postgres;

