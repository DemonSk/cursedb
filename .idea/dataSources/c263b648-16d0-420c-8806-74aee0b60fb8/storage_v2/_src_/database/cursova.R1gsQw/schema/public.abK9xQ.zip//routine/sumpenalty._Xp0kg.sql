create function sumpenalty()
    returns TABLE(driverid integer, sum_penalty_month bigint, start_date timestamp without time zone, end_date timestamp without time zone)
    language plpgsql
as
$$
BEGIN
        for counter in 1..12 loop
    return query (select drivers.driverid,
           sum(penaltycost) as sum_penalty_month,
           date_trunc('month', (current_date - (counter || ' MONTH')::INTERVAL)) as Start_Date,
           date_trunc('month', (current_date - (counter-1 || ' MONTH')::INTERVAL)) as End_Date
           from drivers join ticket t on drivers.driverid = t.personid join penalty p on p.penaltyid = t.penaltyid
    where
           ticketdate <= date_trunc('month', (current_date - (counter-1 || ' MONTH')::INTERVAL)) and
           ticketdate >=  date_trunc('month', (current_date - (counter || ' MONTH')::INTERVAL))
           group by drivers.driverid);
    end loop;
    end;
$$;

alter function sumpenalty() owner to postgres;

